public class Book {
    long isbnNum;
    String title;
    String authorLastName;
    Book(long isbnNum, String title, String lastName){
        this.isbnNum = isbnNum;
        this.title = title;
        authorLastName = lastName;
    }
}
